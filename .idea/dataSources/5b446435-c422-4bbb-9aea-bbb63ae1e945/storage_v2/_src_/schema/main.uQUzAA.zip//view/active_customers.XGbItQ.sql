CREATE VIEW active_customers AS
SELECT customer_id, first_name, last_name, email
FROM banking_customers
WHERE status = 'Active';

