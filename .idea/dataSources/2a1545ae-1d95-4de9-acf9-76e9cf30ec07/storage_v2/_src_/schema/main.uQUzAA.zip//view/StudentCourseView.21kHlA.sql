CREATE VIEW StudentCourseView AS
SELECT s.Name AS StudentName, s.Department, c.CourseName, e.Grade
FROM Students s
INNER JOIN Enrollment e ON s.StudentID = e.StudentID
INNER JOIN Courses c ON e.CourseID = c.CourseID;

